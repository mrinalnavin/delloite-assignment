

let dbData = ''
fetch('./db.json').then((response)=> response.json()).then((data)=>{
  dbData=data
  appendData(data)
})

function goHome(){
  fetch('./db.json').then((response)=> response.json()).then((data)=>{
    dbData=data
    appendData(data)
  })
}
function appendData(data){
  
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < data.length; i++) {
      let div = document.createElement("div");
      let div1 = document.createElement("div");
      let div2 = document.createElement("div");
      let rating = document.createElement("div")
      let span = document.createElement("span");
      let cart = document.createElement("span");
      let img = document.createElement("img");
      
      img.id=data[i].id
      img.src=data[i].img;
      div.appendChild(img);

      div1.innerHTML='<span>'+data[i].name+'</span>';
      div1.setAttribute('style','font-weight: bolder;font-family: sans-serif')
      span.innerHTML=data[i].price;
      span.style.float='right'
      
      div1.appendChild(span);
      div.appendChild(div1);
      let cool=data[i].id
      
      div2.innerHTML=data[i].category;
      cart.innerHTML=`<i id='containerCart' value=${cool}  onclick='addToCart(event)'  style="font-size:24px" class="fa">&#xf07a;</i>`
      cart.style.float='right';
      div2.appendChild(cart)
      
     
      div.appendChild(div2);
      div.appendChild(rating);
      mainContainer.appendChild(div)
  }
}

function myFunction() {
  let x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}


function delegation(event){
  //console.log(event.target.id)
  let element = document.getElementById('page');
  element.parentNode.removeChild(element)
  let id = event.target.id;
  console.log(event.target.id)
  if(id && id!='containerCart'){
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  let div = document.createElement("div");
  let name = document.createElement("span");
  let details = document.createElement('span')
  let img = document.createElement("img");
  let linebreak = document.createElement("br");
  let price = document.createElement('div');
  let priceValue = document.createElement('div');
  let buy = document.createElement('span');
  let  button = document.createElement('button')
  img.src=dbData[id].img;
  img.style.float='left'
  div.appendChild(img);
  
  name.innerHTML=dbData[id].name;
  name.setAttribute('style','position:relative;top:30px;left:300px;font-size: x-large')
  div.appendChild(name);

  div.appendChild(linebreak);
  
  details.innerHTML=dbData[id].details;
  details.setAttribute('style','position:relative;top:50px;left:20px')
  div.appendChild(details)
  
  div.appendChild(linebreak);
  price.innerHTML='Price Per Unit';
  price.setAttribute('style','position:relative;top:70px;left:20px')
  div.appendChild(price);
  

    priceValue.innerHTML=dbData[id].price ;
    priceValue.setAttribute('style','position:relative;top:80px;left:20px;font-family: cursive');
    div.appendChild(priceValue);
    let bu = id
    button.innerHTML=`<span onClick="buyNow()" id='buy'  value=${bu}>Buy Now</span>`;
    buy.appendChild(button);
    buy.setAttribute('style','position: relative;left: 86px;top: 59px;')
    div.appendChild(buy)

  
  mainContainer.appendChild(div)

}
}

function searchFunction(event){
 
let target=document.getElementById('myInput').value.toLowerCase()
let filteredData=dbData.filter((i)=>{
return i.name.toLowerCase().includes(target)
})
console.log(filteredData);
let mainContainer = document.getElementById("list");
mainContainer.innerHTML=null
for (let i = 0; i < filteredData.length; i++) {
  let div = document.createElement("div");
  let div1 = document.createElement("div");
  let div2 = document.createElement("div");
  let span = document.createElement("span")
  let img = document.createElement("img");
  img.id=filteredData[i].id
  img.src=filteredData[i].img;
  div.appendChild(img);

  div1.innerHTML='<span>'+filteredData[i].name+'</span>';
  span.innerHTML=filteredData[i].price;
  span.style.float='right'
  
  div1.appendChild(span);
  div.appendChild(div1);
  
  div2.innerHTML=filteredData[i].category;
  div.appendChild(div2)
  mainContainer.appendChild(div)
}

}
function sortCollection(event){
//console.log(document.getElementById('collection').value)
let target = document.getElementById('collection').value.toLowerCase();
let filteredData=dbData.filter((i)=>{
  return i.category.toLowerCase().includes(target)
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2)
    mainContainer.appendChild(div)

}
}

function sortColour(){
  let target = document.getElementById('colour').value.toLowerCase();
let filteredData=dbData.filter((i)=>{
  return i.color.toLowerCase().includes(target)
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2)
    mainContainer.appendChild(div)

}
}

// let slider = document.getElementById("myRange");
// let output = document.getElementById('demo');
// //output.innerHTML = 200;
// console.log(slider)
// slider.oninput = function() {
//   console.log(this.value)
//   output.innerHTML = this.value;
  
// }

function slider(event){
  let demo=document.getElementById('demo');
  demo.innerHTML=event.target.value;
  priceRange(event.target.value)
  //console.log()
}

function priceRange(price){
  let target = price ;
let filteredData=dbData.filter((i)=>{
  let price = parseInt(i.price.slice(0,3));
  return price>target
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2)
    mainContainer.appendChild(div)
}
}


function addToCart(event){
 
let item = document.getElementById('containerCart');
console.log(event.target.getAttribute('value'));
let target=event.target.getAttribute('value')
let filteredData=dbData.filter((i)=>{
return i.id==target
});

filteredData[0].added=true;
console.log(filteredData);
alert('Added to cart.Please click on Cart icon above to go to your shopping cart')
}

function Cart(){
console.log(dbData);
let filteredData=dbData.filter((i)=>{
  return i.added==true
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null;


  let header = document.createElement('header');
  let linebreak= document.createElement('br')
  mainContainer.appendChild(header)
  header.innerHTML='Items in your cart';
  header.setAttribute('style','width: -webkit-fill-available;font-size: xx-large;')
  mainContainer.appendChild(linebreak)
 
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2);

    
    
    mainContainer.appendChild(div)

}

}

function buyNow(){
  let item = document.getElementById('buy').getAttribute('value')
//console.log(item.getAttribute('value'))
}