

let dbData = ''
fetch('./db.json').then((response)=> response.json()).then((data)=>{
  dbData=data
  appendData(data)
})

function goHome(){
  fetch('./db.json').then((response)=> response.json()).then((data)=>{
    dbData=data
    appendData(data)
  })
}
function appendData(data){
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < data.length; i++) {
      let div = document.createElement("div");
      let div1 = document.createElement("div");
      let div2 = document.createElement("div");
      let span = document.createElement("span")
      let img = document.createElement("img");
      img.id=data[i].id
      img.src=data[i].img;
      div.appendChild(img);

      div1.innerHTML='<span>'+data[i].name+'</span>';
      span.innerHTML=data[i].price;
      span.style.float='right'
      
      div1.appendChild(span);
      div.appendChild(div1);
      
      div2.innerHTML=data[i].category;
      div.appendChild(div2)
      mainContainer.appendChild(div)
  }
}

function myFunction() {
  let x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}


function delegation(event){
  //console.log(event.target.id)
  let id = event.target.id;
  console.log(dbData[id])
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  let div = document.createElement("div");
  let name = document.createElement("span");
  let details = document.createElement('span')
  let img = document.createElement("img");
  let linebreak = document.createElement("br");
  let price = document.createElement('span');
  let priceValue = document.createElement('span');
  img.src=dbData[id].img;
  img.style.float='left'
  div.appendChild(img);
  
  name.innerHTML=dbData[id].name;
  name.setAttribute('style','position:relative;top:30px;left:300px;font-size: x-large')
  div.appendChild(name);

  div.appendChild(linebreak);
  
  details.innerHTML=dbData[id].details;
  details.setAttribute('style','position:relative;top:50px;left:20px')
  div.appendChild(details)
  
  div.appendChild(linebreak);
  // price.innerHTML='Price Per Unit';
  // price.setAttribute('style','position:relative;top:70px;left:20px')
  // div.appendChild(price);
  // div.appendChild(linebreak);

    // priceValue.innerHTML=dbData[id].price ;
    // priceValue.setAttribute('style','position:relative;top:80px;left:20px');
    // div.appendChild(priceValue)

  
  mainContainer.appendChild(div)

}

function searchFunction(event){
 
let target=document.getElementById('myInput').value.toLowerCase()
let filteredData=dbData.filter((i)=>{
return i.name.toLowerCase().includes(target)
})
console.log(filteredData);
let mainContainer = document.getElementById("list");
mainContainer.innerHTML=null
for (let i = 0; i < filteredData.length; i++) {
  let div = document.createElement("div");
  let div1 = document.createElement("div");
  let div2 = document.createElement("div");
  let span = document.createElement("span")
  let img = document.createElement("img");
  img.id=filteredData[i].id
  img.src=filteredData[i].img;
  div.appendChild(img);

  div1.innerHTML='<span>'+filteredData[i].name+'</span>';
  span.innerHTML=filteredData[i].price;
  span.style.float='right'
  
  div1.appendChild(span);
  div.appendChild(div1);
  
  div2.innerHTML=filteredData[i].category;
  div.appendChild(div2)
  mainContainer.appendChild(div)
}

}
function sortCollection(event){
//console.log(document.getElementById('collection').value)
let target = document.getElementById('collection').value.toLowerCase();
let filteredData=dbData.filter((i)=>{
  return i.category.toLowerCase().includes(target)
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2)
    mainContainer.appendChild(div)

}
}

function sortColour(){
  let target = document.getElementById('colour').value.toLowerCase();
let filteredData=dbData.filter((i)=>{
  return i.color.toLowerCase().includes(target)
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2)
    mainContainer.appendChild(div)

}
}

// let slider = document.getElementById("myRange");
// let output = document.getElementById('demo');
// //output.innerHTML = 200;
// console.log(slider)
// slider.oninput = function() {
//   console.log(this.value)
//   output.innerHTML = this.value;
  
// }

function slider(event){
  let demo=document.getElementById('demo');
  demo.innerHTML=event.target.value;
  priceRange(event.target.value)
  //console.log()
}

function priceRange(price){
  let target = price ;
let filteredData=dbData.filter((i)=>{
  let price = parseInt(i.price.slice(0,3));
  return price>target
  })
  console.log(filteredData);
  let mainContainer = document.getElementById("list");
  mainContainer.innerHTML=null
  for (let i = 0; i < filteredData.length; i++) {
    let div = document.createElement("div");
    let div1 = document.createElement("div");
    let div2 = document.createElement("div");
    let span = document.createElement("span")
    let img = document.createElement("img");
    img.id=filteredData[i].id
    img.src=filteredData[i].img;
    div.appendChild(img);
  
    div1.innerHTML='<span>'+filteredData[i].name+'</span>';
    span.innerHTML=filteredData[i].price;
    span.style.float='right'
    
    div1.appendChild(span);
    div.appendChild(div1);
    
    div2.innerHTML=filteredData[i].category;
    div.appendChild(div2)
    mainContainer.appendChild(div)
}
}